from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login as auth_login,logout as auth_logout
from django.contrib.auth.decorators import login_required
from employee.models import EmployeeData
from django.contrib import messages

# Create your views here.
def login(request):
    if request.method == "POST":
        un = request.POST.get('username','')
        pw = request.POST.get('userpassword','')
        user = authenticate(request,username=un,password =pw)
        if user is not None:
            auth_login(request,'user')
            return redirect('home')
    return render(request,'login.html')

@login_required
def home(request):
    return  redirect(request,'home.html')

@login_required
def logout(request):
    auth_logout(request)
    return redirect('login')



@login_required
def dashboard(request):
    employees = EmployeeData.objects.filter(mgr_rel=request.user.id)
    return render(request,'dashboard.html',{'employees':employees})

@login_required
def add_data(request):
    if request.method == 'POST':
        EmployeeData.objects.create(
        eid = request.POST.get('emp_id',''),
        ename = request.POST.get('emp_name',''),
        email = request.POST.get('emp_email',''),
        edep = request.POST.get('emp_department',''),
        erole = request.POST.get('emp_erole',''),
        mgr_rel = request.user
        )
        messages.success(request, "employee added successfuly")
        return redirect('home')