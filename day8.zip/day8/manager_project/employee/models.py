from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class EmployeeData(models.Model):
    eid = models.PositiveSmallIntegerField(primary_key=True)
    ename = models.CharField(max_length=150)
    email = models.EmailField(max_length=245,unique=True)
    edep = models.CharField(choices=[('deva','development'),('Test','testing'),('HR','human resource')])
    erole = models.CharField(default='Junior engineer')
    mgr_rel = models.ForeignKey(User,on_delete=models.CASCADE,related_name='emp')

    def __str__(self):
        return self.ename