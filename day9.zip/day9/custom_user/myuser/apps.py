from django.apps import AppConfig


class MyuserConfig(AppConfig):
    name = 'myuser'
