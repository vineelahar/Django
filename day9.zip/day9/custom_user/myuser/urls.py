from django.urls import path
from .views import user_data_from

urlpatterns = [
    path('',user_data_from,name='form')
]