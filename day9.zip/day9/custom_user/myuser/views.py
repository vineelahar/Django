from django.shortcuts import render
from myuser.form import MyForm
from django.http import HttpResponse

# Create your views here.
def user_data_from(request):
    if request.method == 'POST':
        myform = MyForm(request.POST)
        if myform.is_valid():
            return HttpResponse(f'Thank u{myform.cleaned_data} for submitiin!!!')
    myform = MyForm()
    return render(request,'form.html',{'myform':myform})


