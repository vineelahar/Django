from django.db import models
from django.contrib.auth.models import AbstractBaseUser,PermissionsMixin
from django.contrib.auth.base_user import BaseUserManager

import uuid

# Create your models here.
class MyUserManager(BaseUserManager):
    def create_user(self,email,username='',phn_no=0,password=None,**extra_field):
        if not email:
           raise ValueError('Email is important')
        user = self.model(
        email=self.normalize_email(email),**extra_field     
        )
        user.username = username
        user.phn_no = phn_no
        user.set_password(password)
        user.save(using=self._db)
        return user
    def create_superuser(self,email,username='',phn_no=0,password=None,**extra_field):
        extra_field.setdefault('is_superuser',True)
        extra_field.setdefault('is_staff',True)
        user = self.create_user(email=email,username=username,phn_no=phn_no,password=password,**extra_field)
        return user 
    
class Myuser(AbstractBaseUser,PermissionsMixin):
    user_id = models.UUIDField(default=uuid.uuid4,primary_key=True,unique=True)
    username = models.CharField(max_length=150)
    email = models.EmailField(max_length=150,unique=True)
    phn_no = models.PositiveBigIntegerField(unique=True)
    acc_created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=True)
    is_vendor = models.BooleanField(default=False)
    is_customer = models.BooleanField(default=False)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username','phn_no']

    manager = MyUserManager()
