from django import forms

class MyForm(forms.Form):
    name = forms.CharField(max_length=150,min_length=3,strip=True,label='Enter your name')
    mat_sat = forms.ChoiceField(choices=[('single','s'),('taken','t')])
    # dob=forms.DateField(widget={'type':'data'})
    dob = forms.CharField(widget=forms.TextInput(attrs={'type':'date','class':'dob','id':'mydob'}))