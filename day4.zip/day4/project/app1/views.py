from django.shortcuts import render,redirect
from app1.models import UserData

# Create your views here.
def form_data(request):
    if request.method == 'POST':
        bname = request.POST.get('name','')
        bemail = request.POST.get('email','')
        bmob_no = request.POST.get('mob','')
        user = UserData.objects.create(name=bname,email=bemail,phone_no=bmob_no)
        return redirect('formdata')
        # return redirect(request,'dataform.html',{'name':name,'email':email,'mob_no':mob_no})   
    return render(request,'dataform.html')
    # if request.method =='GET':
    #     if request.GET:
    #         name = request.GET.get('name','')
    #         email = request.GET.get('email','')
    #         mob_no = request.GET.get('mob','')
    #         return render(request,'dataform.html',{'name':name,'email':email,'mob_no':mob_no})
    #     return render(request,'dataform.html')

    # return render(request,'dataform.html')

