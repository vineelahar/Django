from django.db import models

# Create your models here.
class UserData(models.Model):
    name = models.CharField(null=False,max_length=150)
    email = models.EmailField(unique=True,null=False,max_length=150)
    phone_no = models.PositiveBigIntegerField(unique=True,null=False)
    def __str__(self):
        return self.name
