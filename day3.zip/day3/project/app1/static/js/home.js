function printsomething(){
    console.log("CHECK COMPLATED!!!");
    
}