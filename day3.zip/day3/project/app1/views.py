from django.shortcuts import render

# Create your views here.
def home(request):
    students = [{'id':101,'student_name':'Raju','branch':'mech','alive':True},
                {'id':102,'student_name':'ram','branch':'ece','alive':False},
                {'id':103,'student_name':'hari','branch':'cs','alive':True},
                {'id':104,'student_name':'sohel','branch':'cs','alive':True}]
    return render(request,'home.html',context={'stu':students})


def contact(request):
    return render(request,'contact.html')


def about(request):
    return render(request,'about.html')

